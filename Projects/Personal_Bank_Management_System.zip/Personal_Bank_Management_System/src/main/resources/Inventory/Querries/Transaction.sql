SELECT * FROM Transaction;

Truncate Transaction;

